# WAVE MUSIC Android App Source

This project packages the current WAVE MUSIC website snapshot and an Android WebView app wrapper.

## Important
- This ZIP is **Android source code**, not a prebuilt APK.
- The app loads your live WAVE MUSIC website. You must host the website/backend over HTTPS and set its URL before building.
- YouTube search uses your website's backend endpoint (`/api/youtube/search`), so the live site must have the server/API configured.
- The website's Offline Music feature stores user-selected audio files in the device/browser IndexedDB. These files are not uploaded to hosting by this feature; browser/app data clearing can remove them.
- YouTube videos are embedded and cannot be downloaded as audio by this app. Use audio files you own or are authorized to download for offline listening.
- WebView background playback depends on Android/browser/provider restrictions and is not guaranteed for every YouTube embed. A fully reliable native background media service would require a separate native player and a permitted audio source.
- No Spotify playback or Spotify credentials are included in this build.

## 1. Publish the website
1. Upload the contents of `pwa/` to your existing Node/Pterodactyl website project, or use your already-working WAVE MUSIC website.
2. Keep `server.js`, `package.json`, `.env.example`, and `index.html` together as required by your hosting setup.
3. Set the real website URL to HTTPS and confirm YouTube search works on the website.
4. Do not upload real API keys into this ZIP or commit them to GitHub.

## 2. Build the APK (GitHub Actions — easiest)
1. Create a GitHub repository and upload everything in this project (the `android/`, `pwa/`, and `.github/` folders should be at repository root).
2. In GitHub, open **Settings → Secrets and variables → Actions → Variables → New repository variable**.
3. Set `WAVE_URL` to your live HTTPS website URL, e.g. `https://music.example.com/` (replace with your actual URL).
4. Open **Actions → Build WAVE MUSIC Android APK → Run workflow**.
5. When complete, open the workflow run and download the `WAVE-MUSIC-android-apk` artifact. Extract `app-debug.apk` and install it on your Android phone.

## 3. Build locally
Install JDK 17, Android SDK and Gradle 8.9, then run:
`gradle -p android assembleDebug -PwaveUrl=https://YOUR-LIVE-WEBSITE/`

## 4. Offline files
Choose local audio files from inside the app. The website stores those selected files in browser IndexedDB on the device. They are not saved on your hosting server. If the user clears app data, browser data or uninstalls the app, the offline copies may be deleted.
