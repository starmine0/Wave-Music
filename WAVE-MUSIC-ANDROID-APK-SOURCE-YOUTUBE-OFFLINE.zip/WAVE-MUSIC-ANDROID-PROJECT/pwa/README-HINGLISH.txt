WAVE MUSIC + DISCORD STATS — SETUP

1. Upload website files to a Node.js Pterodactyl server. Copy .env.example to .env and fill values.
2. Run `npm install`, then start the WEBSITE server with `npm start`.
3. For Discord bot, use a SECOND Node.js Pterodactyl server with the same package files and .env. Run `npm install`, then `npm run bot`.
4. Invite the bot with applications.commands scope. Set DISCORD_CLIENT_ID and DISCORD_GUILD_ID; bot registers /stats and /helpmenu in that guild.
5. Make a private visit-log channel and set DISCORD_VISIT_LOG_CHANNEL_ID. Bot needs View Channel and Send Messages.
6. Website status endpoint /api/status is used internally by the Discord stats command; it is not printed in the server console.

IMPORTANT LIMITATIONS
- YouTube's API is a search/catalogue API, not an unrestricted audio stream. Videos blocked by the owner, age/region restrictions, deleted videos, etc. cannot be forced to play. The site filters for embeddable videos and uses the official YouTube player. The YouTube player API does not guarantee fixed 144p.
- Browser name is not automatically accessible to a website. Visit logs show “Guest” unless the visitor provides a display name; do not claim a real logged-in identity if no login system exists.
- Visit/listener/active counts are in memory and reset when the website restarts. This build logs visits to the configured Discord channel; do not log IP addresses or secrets. Counts are approximate and not unique lifetime visitors.
- Keep .env private. Never put API secrets in index.html.

UPDATE NOTES (17 Oct 2026)
- Website page se server stats/configuration status section hata diya gaya hai.
- Website icon ke liye Website icon section mein direct public image URL paste karke Save icon dabao. Ye setting current browser/device par save hoti hai; sab visitors ke liye default icon badalne ke liye icon.svg/HTML server par update karna hoga.
- Stop button add hai; playback stop karta hai.